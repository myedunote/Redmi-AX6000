#!/bin/sh

ROOT_DIR=$(CDPATH= cd "$(dirname "$0")/.." 2>/dev/null && pwd) || exit 1
. "$ROOT_DIR/lib/netease-api.sh"
. "$ROOT_DIR/lib/checksum.sh"
. "$ROOT_DIR/lib/download.sh"
. "$ROOT_DIR/lib/archive.sh"
. "$ROOT_DIR/lib/elf.sh"

channel="${1:-openwrt-aarch64}"
stage_dir="${UU_STAGE_DIR:-/tmp/uu-wol-helper-stage}"

case "$stage_dir" in
    /tmp/uu-wol-helper-*/*)
        echo "Unsafe nested stage directory." >&2
        exit 2
        ;;
    /tmp/uu-wol-helper-*) ;;
    *)
        echo "Unsafe stage directory. UU_STAGE_DIR must match /tmp/uu-wol-helper-*" >&2
        exit 2
        ;;
esac

if [ -e "$stage_dir/mips-smoke.lock" ]; then
    echo "MIPS runtime cleanup lock exists; refuse to re-stage or erase recovery evidence." >&2
    exit 65
fi

if [ "$channel" = "openwrt-mipsel" ] && ! uu_elf_have_hex_reader; then
    echo "MIPS stage requires od or hexdump. No package downloaded or files changed." >&2
    exit 4
fi

printf '%s\n' "UU official package staging"
printf '%s\n' "==========================="
printf 'channel: %s\n' "$channel"
printf 'stage_dir: %s\n' "$stage_dir"
printf '%s\n' "persistent_changes: no"
printf '%s\n' "process_changes: no"

if ! uu_api_fetch_and_parse "$channel"; then
    echo "Unable to query or validate the NetEase UU API response." >&2
    exit 1
fi

printf 'api_status: %s\n' "$UU_API_STATUS"
printf 'version: %s\n' "$UU_API_VERSION"
printf 'md5: %s\n' "$UU_API_MD5"

# Never erase a live MIPS test's temporary executable, watchdog state,
# baseline firewall snapshot or recovery evidence during re-staging.
if [ -e "$stage_dir/mips-smoke.lock" ]; then
    echo "An active/incomplete MIPS runtime lock exists; staging refused until cleanup is verified." >&2
    exit 65
fi
if [ "$channel" = "openwrt-mipsel" ]; then
    for proc in /proc/[0-9]*/exe; do
        case "$(readlink "$proc" 2>/dev/null || true)" in
            "$stage_dir/files/uuplugin"|"$stage_dir/files/xuplugin-guardian")
                echo "Staged UU process is active; staging refused." >&2
                exit 65 ;;
        esac
    done
fi
rm -rf "$stage_dir"
mkdir -p "$stage_dir/files" || exit 1
package="$stage_dir/uu.tar.gz"

if ! uu_download_with_fallback "$UU_API_URL" "$UU_API_URL_BAK" "$package"; then
    exit 1
fi

if ! uu_verify_md5 "$package" "$UU_API_MD5"; then
    echo "Official package MD5 verification failed." >&2
    exit 1
fi
printf '%s\n' "md5_check: pass"

metadata="$stage_dir/metadata"
printf 'channel=%s\nversion=%s\nmd5=%s\n' "$channel" "$UU_API_VERSION" "$UU_API_MD5" > "$metadata"

if ! uu_validate_uu_package "$package"; then
    echo "Official package structure validation failed." >&2
    exit 1
fi
printf '%s\n' "archive_check: pass"

if ! uu_extract_uu_package "$package" "$stage_dir/files"; then
    echo "Official package extraction failed." >&2
    exit 1
fi
printf '%s\n' "extract_check: pass"

if [ "$channel" = "openwrt-mipsel" ]; then
    if ! uu_check_stage_mipsel_elf "$stage_dir"; then
        echo "MIPS package ELF architecture/ISA check failed; staging refused." >&2
        exit 1
    fi
    printf '%s\n' "mips_elf_check: pass"
fi

printf '%s\n' "staged_files:"
for file in uuplugin xuplugin-guardian uu.conf xtables-nft-multi; do
    size=$(wc -c < "$stage_dir/files/$file" 2>/dev/null || printf 'unknown')
    printf '  %s (%s bytes)\n' "$file" "$size"
done

printf '%s\n' "STAGE_READY"
printf '%s\n' "No plugin process was stopped or started. No persistent path was modified."
